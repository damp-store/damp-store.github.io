<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{tmsearch}prestashop>tmsearch_be305c865235f417d9b4d22fcdf9f1c5'] = 'Adds a quick search field to your website.';
$_MODULE['<{tmsearch}prestashop>tmsearch_f4f70727dc34561dfde1a3c529b6205c'] = 'Settings';
$_MODULE['<{tmsearch}prestashop>tmsearch_66611c3baf7310cc5a2409bc22e86613'] = 'Enable Ajax Search';
$_MODULE['<{tmsearch}prestashop>tmsearch_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Enabled';
$_MODULE['<{tmsearch}prestashop>tmsearch_b9f5c797ebbf55adccdd8539a65a0241'] = 'Disabled';
$_MODULE['<{tmsearch}prestashop>tmsearch_a6dcc5e58316385e04b58a317fd1e684'] = 'Enable Instant Search';
$_MODULE['<{tmsearch}prestashop>tmsearch_443f095d3948b3002e2d1edf8911a3b6'] = 'Display image in Ajax search';
$_MODULE['<{tmsearch}prestashop>tmsearch_c5ca5ddcf31efd5cfd36094827fb9450'] = 'Display description in Ajax search';
$_MODULE['<{tmsearch}prestashop>tmsearch_7c9552d0f647e60f0a63e518116fd2e3'] = 'Display prices in Ajax search';
$_MODULE['<{tmsearch}prestashop>tmsearch_f9b8b3179810e5e3b3a035d3fece78b0'] = 'Enter scroll max-height for Ajax search';
$_MODULE['<{tmsearch}prestashop>tmsearch_af1ca2d17b716382e59699bdc8ec23e6'] = 'Use scroll in Ajax search';
$_MODULE['<{tmsearch}prestashop>tmsearch_2d43fae7df3565e561edde646641720b'] = 'Scroll max-height';
$_MODULE['<{tmsearch}prestashop>tmsearch_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
$_MODULE['<{tmsearch}prestashop>tmsearch_13348442cc6a27032d2b4aa28b75a5d3'] = 'Search';

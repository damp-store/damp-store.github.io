<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{tmheaderaccount}theme1362>tmheaderaccount_3d01f28f9b86f0fe9bbb9bc3a71fce5b'] = 'Información de la cuenta del cliente en la pantalla de cabecera sitio';
$_MODULE['<{tmheaderaccount}theme1362>customer-account-form-top_d99a9daab2e0d2f1f2de6a92d108c43a'] = 'Registrarse con su cuenta VK';
$_MODULE['<{tmheaderaccount}theme1362>tmheaderaccount_a0623b78a5f2cfe415d9dbbd4428ea40'] = 'Su cuenta';
$_MODULE['<{tmheaderaccount}theme1362>tmheaderaccount_b6d4223e60986fa4c9af77ee5f7149c5'] = 'Iniciar sesión';
$_MODULE['<{tmheaderaccount}theme1362>tmheaderaccount_74ecd9234b2a42ca13e775193f391833'] = 'Mis compras';
$_MODULE['<{tmheaderaccount}theme1362>tmheaderaccount_5973e925605a501b18e48280f04f0347'] = 'Mis devoluciones';
$_MODULE['<{tmheaderaccount}theme1362>tmheaderaccount_89080f0eedbd5491a93157930f1e45fc'] = 'Mis devoluciones';
$_MODULE['<{tmheaderaccount}theme1362>tmheaderaccount_9132bc7bac91dd4e1c453d4e96edf219'] = 'Mis vales descuento';
$_MODULE['<{tmheaderaccount}theme1362>tmheaderaccount_e45be0a0d4a0b62b15694c1a631e6e62'] = 'Mis direcciones';
$_MODULE['<{tmheaderaccount}theme1362>tmheaderaccount_b4b80a59559e84e8497f746aac634674'] = 'Mis datos personales';
$_MODULE['<{tmheaderaccount}theme1362>tmheaderaccount_63b1ba91576576e6cf2da6fab7617e58'] = 'Mis datos personales';
$_MODULE['<{tmheaderaccount}theme1362>tmheaderaccount_95d2137c196c7f84df5753ed78f18332'] = 'Mis vales';
$_MODULE['<{tmheaderaccount}theme1362>tmheaderaccount_c87aacf5673fada1108c9f809d354311'] = 'Cerrar sesión';
$_MODULE['<{tmheaderaccount}theme1362>tmheaderaccount_b357b524e740bc85b9790a0712d84a30'] = 'Correo electrónico';
$_MODULE['<{tmheaderaccount}theme1362>tmheaderaccount_dc647eb65e6711e155375218212b3964'] = 'Contraseña';
$_MODULE['<{tmheaderaccount}theme1362>tmheaderaccount_2fdfd506efea08144c0794c32ca8250a'] = 'Crear una cuenta';

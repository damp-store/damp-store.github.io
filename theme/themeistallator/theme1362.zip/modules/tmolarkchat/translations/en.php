<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{tmolarkchat}prestashop>tmolarkchat_55d7b913605c1ceada08e487b32d82fd'] = 'Chat with Customers directly through your Olark ID.';
$_MODULE['<{tmolarkchat}prestashop>tmolarkchat_69a1a3ad8dd5da6db3c4da838a0cf9c7'] = 'Are you sure you want to delete your details?';
$_MODULE['<{tmolarkchat}prestashop>tmolarkchat_1b7a7792cb61a424734ec6c34fbbc6e8'] = 'Embed ID is required in live mode.';
$_MODULE['<{tmolarkchat}prestashop>tmolarkchat_9a7e58ee13cb727cb7c4acc68f4cafe5'] = 'Settings saved.';
$_MODULE['<{tmolarkchat}prestashop>tmolarkchat_f4f70727dc34561dfde1a3c529b6205c'] = 'Settings';
$_MODULE['<{tmolarkchat}prestashop>tmolarkchat_cebd5bbe0ffdecc270a8a324e5a277dd'] = 'Live mode';
$_MODULE['<{tmolarkchat}prestashop>tmolarkchat_ea9df7a306e2f8b5af37b67084d0c984'] = 'Use this module in live mode';
$_MODULE['<{tmolarkchat}prestashop>tmolarkchat_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Enabled';
$_MODULE['<{tmolarkchat}prestashop>tmolarkchat_b9f5c797ebbf55adccdd8539a65a0241'] = 'Disabled';
$_MODULE['<{tmolarkchat}prestashop>tmolarkchat_a586138e4f4d669d8b8483e950675e8c'] = 'Enter a valid Olark Chat ID';
$_MODULE['<{tmolarkchat}prestashop>tmolarkchat_ed6af790b6755e7ff0d93c5edd754b00'] = 'Olark site ID';
$_MODULE['<{tmolarkchat}prestashop>tmolarkchat_c9cc8cce247e49bae79f15173ce97354'] = 'Save';

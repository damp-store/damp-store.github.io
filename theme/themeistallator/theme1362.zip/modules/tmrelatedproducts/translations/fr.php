<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{tmrelatedproducts}prestashop>tmrelatedproducts_711b2cf198cbb552836017b5136d8dce'] = 'Ce module affiche des produits liés sur la page produit';
$_MODULE['<{tmrelatedproducts}prestashop>tmrelatedproducts_f3e944fc8fd7c5d5aa6341e076681189'] = 'Etes-vous sûr de vouloir supprimer toutes les informations sur les produits liés?';
$_MODULE['<{tmrelatedproducts}prestashop>tmrelatedproducts_462390017ab0938911d2d4e964c0cab7'] = 'Paramètres ont été mis à jour avec succès';
$_MODULE['<{tmrelatedproducts}prestashop>tmrelatedproducts_f4f70727dc34561dfde1a3c529b6205c'] = 'Réglages';
$_MODULE['<{tmrelatedproducts}prestashop>tmrelatedproducts_b6bf131edd323320bac67303a3f4de8a'] = 'Afficher le prix sur les produits';
$_MODULE['<{tmrelatedproducts}prestashop>tmrelatedproducts_70f9a895dc3273d34a7f6d14642708ec'] = 'Afficher le prix sur les produits dans le bloc.';
$_MODULE['<{tmrelatedproducts}prestashop>tmrelatedproducts_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Activé';
$_MODULE['<{tmrelatedproducts}prestashop>tmrelatedproducts_b9f5c797ebbf55adccdd8539a65a0241'] = 'Désactivé';
$_MODULE['<{tmrelatedproducts}prestashop>tmrelatedproducts_19a799a6afd0aaf89bc7a4f7588bbf2c'] = 'Nombre de produits affichés';
$_MODULE['<{tmrelatedproducts}prestashop>tmrelatedproducts_02128de6a3b085c72662973cd3448df2'] = 'Définissez le nombre de produits affichés dans ce bloc.';
$_MODULE['<{tmrelatedproducts}prestashop>tmrelatedproducts_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{tmrelatedproducts}prestashop>tmrelatedproducts_tab_347da0da598694c57fff1cbaa197d615'] = 'Produits liés';
$_MODULE['<{tmrelatedproducts}prestashop>tmrelatedproducts_tab_ea4788705e6873b424c65e91c2846b19'] = 'Annuler';
$_MODULE['<{tmrelatedproducts}prestashop>tmrelatedproducts_tab_c9cc8cce247e49bae79f15173ce97354'] = 'Enregistrer';
$_MODULE['<{tmrelatedproducts}prestashop>tmrelatedproducts_tab_9ea67be453eaccf020697b4654fc021a'] = 'Enregistrer et rester';
$_MODULE['<{tmrelatedproducts}prestashop>tmrelatedproducts_38070661d5ad384d9c7d21895dc4e784'] = 'Produits liés';
$_MODULE['<{tmrelatedproducts}prestashop>tmrelatedproducts_2d0f6b8300be19cf35e89e66f0677f95'] = 'Ajouter au panier';

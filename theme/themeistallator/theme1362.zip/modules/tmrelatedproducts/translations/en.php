<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{tmrelatedproducts}prestashop>tmrelatedproducts_711b2cf198cbb552836017b5136d8dce'] = 'This module display related products on product info page';
$_MODULE['<{tmrelatedproducts}prestashop>tmrelatedproducts_f3e944fc8fd7c5d5aa6341e076681189'] = 'Are you sure that you want to delete all your related products info?';
$_MODULE['<{tmrelatedproducts}prestashop>tmrelatedproducts_462390017ab0938911d2d4e964c0cab7'] = 'Settings updated successfully';
$_MODULE['<{tmrelatedproducts}prestashop>tmrelatedproducts_f4f70727dc34561dfde1a3c529b6205c'] = 'Settings';
$_MODULE['<{tmrelatedproducts}prestashop>tmrelatedproducts_b6bf131edd323320bac67303a3f4de8a'] = 'Display price on products';
$_MODULE['<{tmrelatedproducts}prestashop>tmrelatedproducts_70f9a895dc3273d34a7f6d14642708ec'] = 'Show the price on the products in the block.';
$_MODULE['<{tmrelatedproducts}prestashop>tmrelatedproducts_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Enabled';
$_MODULE['<{tmrelatedproducts}prestashop>tmrelatedproducts_b9f5c797ebbf55adccdd8539a65a0241'] = 'Disabled';
$_MODULE['<{tmrelatedproducts}prestashop>tmrelatedproducts_19a799a6afd0aaf89bc7a4f7588bbf2c'] = 'Number of displayed products';
$_MODULE['<{tmrelatedproducts}prestashop>tmrelatedproducts_02128de6a3b085c72662973cd3448df2'] = 'Set the number of products displayed in this block.';
$_MODULE['<{tmrelatedproducts}prestashop>tmrelatedproducts_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
$_MODULE['<{tmrelatedproducts}prestashop>tmrelatedproducts_tab_347da0da598694c57fff1cbaa197d615'] = 'Related Products';
$_MODULE['<{tmrelatedproducts}prestashop>tmrelatedproducts_tab_ea4788705e6873b424c65e91c2846b19'] = 'Cancel';
$_MODULE['<{tmrelatedproducts}prestashop>tmrelatedproducts_tab_c9cc8cce247e49bae79f15173ce97354'] = 'Save';
$_MODULE['<{tmrelatedproducts}prestashop>tmrelatedproducts_tab_9ea67be453eaccf020697b4654fc021a'] = 'Save and stay';
$_MODULE['<{tmrelatedproducts}prestashop>tmrelatedproducts_38070661d5ad384d9c7d21895dc4e784'] = 'Related products';

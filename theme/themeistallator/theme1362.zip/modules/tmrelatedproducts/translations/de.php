<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{tmrelatedproducts}prestashop>tmrelatedproducts_711b2cf198cbb552836017b5136d8dce'] = 'Dieses Modul zeigt ähnliche Produkte auf der Produktinformationsseite an';
$_MODULE['<{tmrelatedproducts}prestashop>tmrelatedproducts_f3e944fc8fd7c5d5aa6341e076681189'] = 'Sind Sie sicher, dass Sie alle Ihre ähnliche Produkte Info löschen möchten?';
$_MODULE['<{tmrelatedproducts}prestashop>tmrelatedproducts_462390017ab0938911d2d4e964c0cab7'] = 'Einstellungen erfolgreich aktualisiert';
$_MODULE['<{tmrelatedproducts}prestashop>tmrelatedproducts_f4f70727dc34561dfde1a3c529b6205c'] = 'Einstellungen ';
$_MODULE['<{tmrelatedproducts}prestashop>tmrelatedproducts_b6bf131edd323320bac67303a3f4de8a'] = 'Produktpreis anzeigen';
$_MODULE['<{tmrelatedproducts}prestashop>tmrelatedproducts_70f9a895dc3273d34a7f6d14642708ec'] = 'Produktpreis im Block anzeigen.';
$_MODULE['<{tmrelatedproducts}prestashop>tmrelatedproducts_00d23a76e43b46dae9ec7aa9dcbebb32'] = 'Aktiviert';
$_MODULE['<{tmrelatedproducts}prestashop>tmrelatedproducts_b9f5c797ebbf55adccdd8539a65a0241'] = 'Deaktiviert';
$_MODULE['<{tmrelatedproducts}prestashop>tmrelatedproducts_19a799a6afd0aaf89bc7a4f7588bbf2c'] = 'Anzahl der angezeigten Produkte';
$_MODULE['<{tmrelatedproducts}prestashop>tmrelatedproducts_02128de6a3b085c72662973cd3448df2'] = 'Legen Sie die Anzahl der angezeigten Produkte in diesem Block fest.';
$_MODULE['<{tmrelatedproducts}prestashop>tmrelatedproducts_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';
$_MODULE['<{tmrelatedproducts}prestashop>tmrelatedproducts_tab_347da0da598694c57fff1cbaa197d615'] = 'Ähnliche Produkte';
$_MODULE['<{tmrelatedproducts}prestashop>tmrelatedproducts_tab_ea4788705e6873b424c65e91c2846b19'] = 'Schließen';
$_MODULE['<{tmrelatedproducts}prestashop>tmrelatedproducts_tab_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';
$_MODULE['<{tmrelatedproducts}prestashop>tmrelatedproducts_tab_9ea67be453eaccf020697b4654fc021a'] = 'Speichern und bleiben';
$_MODULE['<{tmrelatedproducts}prestashop>tmrelatedproducts_38070661d5ad384d9c7d21895dc4e784'] = 'Ähnliche Produkte';
$_MODULE['<{tmrelatedproducts}prestashop>tmrelatedproducts_2d0f6b8300be19cf35e89e66f0677f95'] = 'In den Warenkorb legen';

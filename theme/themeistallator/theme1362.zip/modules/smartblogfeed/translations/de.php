<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{smartblogfeed}prestashop>smartblogfeed_c393a650824fd3ac8e147306a2a1b10c'] = 'RSS Feed  Smart Blog .';
$_MODULE['<{smartblogfeed}prestashop>smartblogfeed_f39479e80017ac7fdf59a5d92208f88e'] = 'RSS Feed Smart Blog erstellen.';
$_MODULE['<{smartblogfeed}prestashop>smartblogfeed_21ee0d457c804ed84627ec8345f3c357'] = 'Einstellungen wurden erfolgreich gespeichert.';
$_MODULE['<{smartblogfeed}prestashop>smartblogfeed_70f2c15a2c9bf860a0de69d13c1f75ea'] = 'Alle Felder müssen ausgefüllt sein';
$_MODULE['<{smartblogfeed}prestashop>smartblogfeed_c54f9f209ed8fb4683e723daa4955377'] = 'Hauptparameter';
$_MODULE['<{smartblogfeed}prestashop>smartblogfeed_0ff5174a1c0afd0f6b8f8e9495a7262e'] = 'Aktualisierungszeitraum';
$_MODULE['<{smartblogfeed}prestashop>smartblogfeed_3d3294d044b2f8dc5fd6d34ca2dcd3ff'] = 'Aktualisierungshäufigkeit';
$_MODULE['<{smartblogfeed}prestashop>smartblogfeed_c07627a5fdfbe3e2044adc04bcd675b0'] = 'Aktualisierungsdauer';
$_MODULE['<{smartblogfeed}prestashop>smartblogfeed_c9cc8cce247e49bae79f15173ce97354'] = 'Speichern';
